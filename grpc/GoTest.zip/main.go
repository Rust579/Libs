package main

import (
	"archive/zip"
	"context"
	"crypto/md5"
	"crypto/rc4"
	"crypto/sha1"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"encoding/xml"
	"errors"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"

	_ "github.com/dgrijalva/jwt-go"
	_ "github.com/go-sql-driver/mysql"
)

// Взаимодействие с ФС

func fileSystem() {
	filePath := "example.txt"
	err := os.WriteFile(filePath, []byte("This is a test"), 0666) // слишком высокий уровень доступа
	if err != nil {
		log.Fatalf("Failed to write to file: %s", err)
	}
	fmt.Println("File created with poor permissions:", filePath)

	os.OpenFile(filePath, os.O_RDONLY, 0666) // слишком высокий уровень доступа

	dirPath := "example_dir"
	err = os.Mkdir(dirPath, 0777) // слишком высокий уровень доступа
	if err != nil {
		log.Fatalf("Failed to create directory: %s", err)
	}
	fmt.Println("Directory created with poor permissions:", dirPath)

	tempFile, err := ioutil.TempFile("", "example_temp_file")
	if err != nil {
		log.Fatalf("Failed to create temporary file: %s", err)
	}
	defer os.Remove(tempFile.Name()) // возвращаемое значение не обработано
	fmt.Println("Temporary file created:", tempFile.Name())

	tempDir, err := ioutil.TempDir("", "example_temp_dir")
	if err != nil {
		log.Fatalf("Failed to create temporary directory: %s", err) // в этом случае не отработает os.RemoveAll(tempDir)
	}
	defer os.RemoveAll(tempDir) // возвращаемое значение не обработано
	fmt.Println("Temporary directory created:", tempDir)

	repoFile := "/safe/path/../../private/path"
	if !strings.HasPrefix(repoFile, "/safe/path/") {
		panic(fmt.Errorf("Unsafe input"))
	}
	byContext, err := ioutil.ReadFile(repoFile)
	if err != nil {
		panic(err)
	}
	fmt.Printf("%s", string(byContext))
}

// Места инъекций, экранирование
// Взаимодействие с SQL СУБД

func injection() {
	db, err := sql.Open("sqlite3", ":memory:")
	if err != nil {
		panic(err)
	}
	q := fmt.Sprintf("SELECT * FROM foo where name = '%s'", os.Args[1]) // SQL инъекция
	rows, err := db.Query(q)
	if err != nil {
		panic(err)
	}
	defer rows.Close()

	db, err = sql.Open("sqlite3", ":memory:")
	if err != nil {
		panic(err)
	}
	var gender string = "M"
	rows, err = db.Query("SELECT * FROM foo WHERE gender = " + gender) // SQL инъекция
	if err != nil {
		panic(err)
	}
	defer rows.Close()

	unzip("1", "2")
}

func unzip(archive, target string) error {
	reader, err := zip.OpenReader(archive)
	if err != nil {
		return err
	}

	// Обход пути. Используя специальные элементы, такие как разделители ".." и "/",
	// злоумышленники могут выйти за пределы каталога с ограниченным доступом и получить доступ к файлам или каталогам,
	// которые находятся в другом месте системы.
	for _, file := range reader.File {
		path := filepath.Join(target, file.Name)
		if file.FileInfo().IsDir() {
			if err := os.MkdirAll(path, file.Mode()); err != nil {
				return err
			}
			continue
		}

		fileReader, err := file.Open()
		if err != nil {
			return err
		}
		defer fileReader.Close()

		targetFile, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, file.Mode()) // Вероятность использование файла с пользовательским вводом
		if err != nil {
			return err
		}
		defer targetFile.Close()

		if _, err := io.Copy(targetFile, fileReader); err != nil {
			return err
		}
	}

	htt()

	return nil
}

func htt() {
	http.HandleFunc("/cmdinjection", cmdInjectionHandler)
}

func cmdInjectionHandler(w http.ResponseWriter, r *http.Request) {
	filename := r.URL.Query().Get("filename")
	cmd := exec.Command("cat", filename) // Командная инъекция
	output, err := cmd.CombinedOutput()
	if err != nil {
		http.Error(w, "Command execution error", http.StatusInternalServerError)
		return
	}

	fmt.Fprintf(w, "Command output: %s", string(output))
}

// Веб-взаимодействие по HTTP

func httphttp() {
	resp, err := http.Get("http://example.com/") // Отсутствует закрытие тела запроса
	if err != nil {

	}
	body, err := ioutil.ReadAll(resp.Body)
	fmt.Println(string(body))
}

func Send(body io.Reader) error {
	req, err := http.NewRequest(http.MethodPost, "http://example.com", body) // не используется контекст
	if err != nil {
		return err
	}
	_, err = http.DefaultClient.Do(req) // Отсутствует закрытие тела запроса
	if err != nil {
		return err
	}

	log.Fatal(http.ListenAndServe(":8080", nil)) // http.ListenAndServe функция не поддерживает использование таймаутов

	return nil
}

// Работа с памятью

func unzipp(archive, target string) error {
	reader, err := zip.OpenReader(archive)
	if err != nil {
		return err
	}

	for _, file := range reader.File {
		path := filepath.Join(target, file.Name)
		if file.FileInfo().IsDir() {
			if err := os.MkdirAll(path, file.Mode()); err != nil {
				return err
			}
			continue
		}

		fileReader, err := file.Open()
		if err != nil {
			return err
		}

		targetFile, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, file.Mode())
		if err != nil {
			return err
		}

		if _, err := io.Copy(targetFile, fileReader); err != nil { // Вероятность получения декомпрессионной бомбы
			return err
		}
	}

	return nil
}

// Рекурсивный вызов
func infiniteRecursiveCall() {
	infiniteRecursiveCall()
}

// Циклы, переключатели, условия

func emptyForLoop() {
	for {
		// Пустой цикл
	}
}

func Worker(id int, client *http.Client, urls chan string, ctx context.Context, wg *sync.WaitGroup) {
	fmt.Printf("Worker %d is starting\n", id)
	for {
		select {
		case url := <-urls:
			fmt.Printf("Worker :%d received url :%s\n", id, url)
		case <-ctx.Done():
			fmt.Printf("Worker :%d exitting..\n", id)
			break // выход их select, а не из цикла
		}
	}

	wg.Done() // Недостежимый код
}

func someOperation() error {
	slice := []string{"1", "2"}

	if len(slice) < 0 { // Всегда будет false
		fmt.Println("unreachable code")
	}

	return errors.New("simulated error")
}

// Возврат функций

func returned() {
	tempFile, err := ioutil.TempFile("", "example_temp_file")
	if err != nil {
		log.Fatalf("Failed to create temporary file: %s", err)
	}
	defer os.Remove(tempFile.Name()) // возвращаемое значение не обработано
	fmt.Println("Temporary file created:", tempFile.Name())

	tempDir, err := ioutil.TempDir("", "example_temp_dir")
	if err != nil {
		log.Fatalf("Failed to create temporary directory: %s", err)
	}
	defer os.RemoveAll(tempDir) // возвращаемое значение не обработано
	fmt.Println("Temporary directory created:", tempDir)

	resp, err := http.Get("http://example.com/")
	if err != nil { // ошибка не обработана

	}
	body, err := ioutil.ReadAll(resp.Body) // ошибка не обработана
	fmt.Println(string(body))
}

func handler(w http.ResponseWriter, r *http.Request) {
	err := someOperation()
	if err != nil {
		http.Error(w, "Internal Server Error", http.StatusInternalServerError) // Пропущен возврат ошибки
	}

	w.Write([]byte("Operation successful")) // Не обработана возвращаемая ошибка
}

// Стиль программирования

func style() {
	db, err := sql.Open("sqlite3", ":memory:")
	if err != nil {
		panic(err)
	}
	var gender string = "M" // Можно исключить объявление типа
	rows, err := db.Query("SELECT * FROM foo WHERE gender = " + gender)
	if err != nil {
		panic(err)
	}
	defer rows.Close()

	Worker(1, nil, nil, context.Background(), nil)
}

func validateEmailFormat1(email string) bool {
	if strings.Contains(email, "@") && strings.Contains(email, ".") {
		return true
	} else { // Можно избавиться от конструкции else
		return false
	}
}

// Криптография, шифрование

func weakEncryptionMD5(data string) string {
	hash := md5.Sum([]byte(data)) // Использование слабого механизма шифрования
	return hex.EncodeToString(hash[:])
}

func weakEncryptionSHA1(data string) string {
	hash := sha1.Sum([]byte(data)) // Использование слабого механизма шифрования
	return hex.EncodeToString(hash[:])
}

func weakEncryptionRC4(data, key string) string {
	cipher, _ := rc4.NewCipher([]byte(key)) // Использование слабого механизма шифрования
	encrypted := []byte(data)
	cipher.XORKeyStream(encrypted, encrypted)
	return hex.EncodeToString(encrypted)
}

// Хранение секретных данных

func secret() {
	password := "pdaoegaeigj[0943ut4329toapisgdjnoiqeh9ujoiasdhao98sd7gt8de7tfayefgad8asedfgasdLJHFCLJHFVLKJHV" // Хардкод (Хранение секретных данных)
	fmt.Println(password)
}

// Парсинг XML, JSON

func JSONHelloWorld(w http.ResponseWriter, r *http.Request) {
	response := struct {
		Message string
		Code    int
	}{
		Message: "Hello World",
		Code:    200,
	}

	body, err := json.Marshal(response) // В структуре response не проставлены тэги json
	if err != nil {
		panic(err)
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(body)
}

func XMLHelloWorld(w http.ResponseWriter, r *http.Request) {
	response := struct {
		XMLName xml.Name
		Message string
		Code    int
	}{
		Message: "Hello World",
		Code:    200,
	}

	body, err := xml.Marshal(response) // В структуре response не проставлены тэги xml
	if err != nil {
		panic(err)
	}

	w.Header().Set("Content-Type", "application/xml")
	w.Write(body)
}

// Соответствие DRY

// Повторяющийся код
func validateEmailFormat(email string) bool {
	if strings.Contains(email, "@") && strings.Contains(email, ".") {
		return true
	} else {
		return false
	}
}

func validateEmailFormat2(email string) bool {
	if strings.Contains(email, "@") && strings.Contains(email, ".") {
		return true
	} else {
		return false
	}
}
