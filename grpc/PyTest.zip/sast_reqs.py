import pillow
import requests
import urllib3
import django
import cryptography
import pyyaml
import paramiko

#--------------------------------------------------------------------------------------------
#Взаимодействие с файловой системой

#Проверка прав доступа
#CWE-732: Incorrect Permission Assignment for Critical Resource
os.chmod('/etc/hosts', 0o777)
os.chmod('/tmp/oh_hai', 0x1ff)
os.chmod('/etc/passwd', stat.S_IRWXU)
os.chmod('/etc/passwd', stat.S_IRWXU)
os.chmod(key_file, 0o777)
os.chmod(key_file, 0o777)

#После извлечения файлов, необходимо убедиться, что они имеют соответствующие права доступа.
#CWE-22: Improper Limitation of a Pathname to a Restricted Directory ('Path Traversal')
import tarfile
def unsafe_archive_handler(filename):
    tar = tarfile.open(filename)
    tar.extractall(path=tempfile.mkdtemp())
    tar.close()

#отсутствия проверки содержимого архива перед его извлечением
#CWE-22: Improper Limitation of a Pathname to a Restricted Directory ('Path Traversal')
import tarfile
def unsafe_archive_handler(filename):
    tar = tarfile.open(filename)
    tar.extractall(path=tempfile.mkdtemp())
    tar.close()

#Предоставление слишком широких прав доступа
#CWE-732: Incorrect Permission Assignment for Critical Resource
os.chmod('file.txt', 0o777)

#использование временных файлов, которые не защищены должным образом
#CWE-377: Insecure Temporary File
tmp_dirs = ['/tmp', '/var/tmp', '/dev/shm']

#Проверка, что извлекаемые файлы имеют минимальные права доступа, необходимые для выполнения их функций
#CWE-22: Improper Limitation of a Pathname to a Restricted Directory ('Path Traversal')
import tarfile
def unsafe_archive_handler(filename):
    tar = tarfile.open(filename)
    tar.extractall(path=tempfile.mkdtemp())
    tar.close()

#--------------------------------------------------------------------------------------------
#Взаимодействие с SQL СУБД

#внешние данные используются в SQL-запросах без должного экранирования
#CWE-89: SQL Injection
identifier = 1
query = "DELETE FROM foo WHERE id = '%s'" % identifier
query = "UPDATE foo SET value = 'b' WHERE id = '%s'" % identifier

#--------------------------------------------------------------------------------------------
#Веб-взаимодействие по HTTP, CORS, cookies

#скриптовые HTML-теги не экранируются должным образом
#CWE-80: Improper Neutralization of Script-Related HTML Tags in a Web Page (Basic XSS)
mako.template.Template("hern")
template.Template("hern")

#Когда нескольким сокетам разрешено привязываться к одному и тому же порту, 
#другие службы на этом порту могут быть украдены или подделаны. 
#CWE-605 Double Free or Incorrect Free of Memory
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(('0.0.0.0', 31137))
s.bind(('192.168.0.1', 8080))

#--------------------------------------------------------------------------------------------
#Работа с памятью
#--------------------------------------------------------------------------------------------
#Система должна использовать передовые методы анализа кода, способные выявлять потенциальные уязвимости,
#такие как утечки памяти и переполнения буфера.

#программа потребляет ресурсы (сетевые соединения) неконтролируемым образом (не установлен таймаут)
#CWE-400: Uncontrolled Resource Consumption ('Resource Exhaustion')
requests.get('https://gmail.com', verify=True)
requests.get('https://gmail.com', verify=False)
requests.post('https://gmail.com', verify=True)

#--------------------------------------------------------------------------------------------
#Циклы, переключатели, условия

#Проверка продолжения в блоке исключений (может привести к некорректному выполнению программы)
#CWE-703: Improper Check or Handling of Exceptional Conditions
while 1:
    try:
        a = 1
    except:
        continue

#недостаточная обработка крайних случаев
#CWE-703: Improper Check or Handling of Exceptional Conditions
try:   
    a = 1
except:
    pass

#--------------------------------------------------------------------------------------------
#Места инъекций, экранирование

#внешние данные используются в командах операционной системы без должного экранирования
#CWE-78: OS Command Injection
paramiko.exec_command('something; really; unsafe')

#внешние данные используются в SQL-запросах без должного экранирования
#CWE-89: SQL Injection
identifier = 1
query = "DELETE FROM foo WHERE id = '%s'" % identifier
query = "UPDATE foo SET value = 'b' WHERE id = '%s'" % identifier

#интерактивный отладчик может быть использован злоумышленником для выполнения произвольного кода на сервере
#CWE-94: Improper Control of Generation of Code 
from flask import Flask
app = Flask(__name__)
app.run(debug=True)

#внешние данные используются в командах операционной системы без должного экранирования
#CWE-78: OS Command Injection
paramiko.exec_command('something; really; unsafe')

#внешние данные используются в SQL-запросах без должного экранирования
#CWE-89: SQL Injection
identifier = 1
query = "DELETE FROM foo WHERE id = '%s'" % identifier
query = "UPDATE foo SET value = 'b' WHERE id = '%s'" % identifier

#проверка xml, yaml инъекций
#CWE-20: Improper Input Validation
ystr = yaml.dump({'a' : 1, 'b' : 2, 'c' : 3})
y = yaml.load(ystr)
yaml.dump(y)

#--------------------------------------------------------------------------------------------
#Правила доступа, разрешения

#потенциальное нарушение механизма авторизации
#CWE-703: Improper Check or Handling of Exceptional Conditions
assert logged_in
display_assets()

#--------------------------------------------------------------------------------------------
#Обработка текстовой информации

#входные данные не проверяются должным образом  
#CWE-20: Improper Input Validation
ystr = yaml.dump({'a' : 1, 'b' : 2, 'c' : 3})
y = yaml.load(ystr)
yaml.dump(y)

#внешние данные используются в командах операционной системы без должного экранирования
#CWE-78: OS Command Injection
paramiko.exec_command('something; really; unsafe')

#обнаружение скрытых управляющих символов
#CWE-838: Inappropriate Encoding for Output Context
access_level = "user"
if access_level != 'none‮⁦': # Check if admin ⁩⁦' and access_level != 'user
    print("You are an admin.\n")

#входные данные не проверяются должным образом  
#CWE-20: Improper Input Validation
ystr = yaml.dump({'a' : 1, 'b' : 2, 'c' : 3})
y = yaml.load(ystr)
yaml.dump(y)

#скриптовые HTML-теги не экранируются должным образом
#CWE-80: Improper Neutralization of Script-Related HTML Tags in a Web Page (Basic XSS)
mako.template.Template("hern")
template.Template("hern")

#обнаружение скрытых управляющих символов
#CWE-838: Inappropriate Encoding for Output Context
access_level = "user"
if access_level != 'none‮⁦': # Check if admin ⁩⁦' and access_level != 'user
    print("You are an admin.\n")

#входные данные не проверяются должным образом  
#CWE-20: Improper Input Validation
ystr = yaml.dump({'a' : 1, 'b' : 2, 'c' : 3})
y = yaml.load(ystr)
yaml.dump(y)

#внешние данные используются в командах операционной системы без должного экранирования
#CWE-78: OS Command Injection
paramiko.exec_command('something; really; unsafe')

#обнаружение скрытых управляющих символов
#CWE-838: Inappropriate Encoding for Output Context
access_level = "user"
if access_level != 'none‮⁦': # Check if admin ⁩⁦' and access_level != 'user
    print("You are an admin.\n")


#--------------------------------------------------------------------------------------------
#Работа с внешними зависимостями
#--------------------------------------------------------------------------------------------

import pycrypto

#без проверки содержимого архива может привести к извлечению вредоносных файлов
#CWE-22: Improper Limitation of a Pathname to a Restricted Directory ('Path Traversal')
import tarfile
def unsafe_archive_handler(filename):
    tar = tarfile.open(filename)
    tar.extractall(path=tempfile.mkdtemp())
    tar.close()

#файл с зависимостями

#--------------------------------------------------------------------------------------------
#Хранение секретных данных

# Использование небезопасных версий SNMP и режимов без шифрования может привести к утечке конфиденциальной информации. 
#CWE-319: Cleartext Transmission of Sensitive Information
from pysnmp.hlapi import CommunityData, UsmUserData

a = CommunityData('public', mpModel=0)
insecure = UsmUserData("securityName")

#жестко закодированные пароли
#CWE-259: Use of Hard-coded Password
def someFunction2(password):
    if password == "root":
        print("OK, logged in")
doLogin(password="blerg")

#--------------------------------------------------------------------------------------------
#Криптография, шифрование
#--------------------------------------------------------------------------------------------

# используются сломанные или рискованные криптографические алгоритмы
#CWE-327: Use of a Broken or Risky Cryptographic Algorithm
#используется недостаточно сильное шифрование
#CWE-326: Inadequate Encryption Strength
ssl.wrap_socket(ssl_version=ssl.PROTOCOL_SSLv3)
ssl.wrap_socket(ssl_version=ssl.PROTOCOL_TLSv1)

def open_ssl_socket(version=SSL.SSLv2_METHOD):
    pass
ssl.wrap_socket()


import hashlib
hashlib.new('md5')

#используется недостаточно сильное шифрование
#CWE-326: Inadequate Encryption Strength
dsa.generate_private_key(512, backends.default_backend())

#неправильная проверка сертификатов в программном обеспечении
#CWE-295: Improper Certificate Validation
requests.get('https://gmail.com', verify=True)
requests.get('https://gmail.com', verify=False)
requests.post('https://gmail.com', verify=True)


#--------------------------------------------------------------------------------------------
#Парсинг XML, JSON

#входные данные не проверяются должным образом
#CWE-20: Improper Input Validation

import xml.sax
from xml import sax

def main():
    xmlString = "<note>\n<to>Tove</to>\n<from>Jani</from>\n<heading>Reminder</heading>\n<body>Don't forget me this weekend!</body>\n</note>"
    xml.sax.parseString(xmlString, ExampleContentHandler())
    xml.sax.parse('notaxmlfilethatexists.xml', ExampleContentHandler())
    sax.parseString(xmlString, ExampleContentHandler())
    sax.parse('notaxmlfilethatexists.xml', ExampleContentHandler)