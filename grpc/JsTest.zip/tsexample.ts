// 1) Взаимодействие с файловой системой

import * as fs from "fs";

function loadModule(moduleName: string): any {
  return require(moduleName); // Использование переменной в функции require может позволить злоумышленнику загрузить и запустить произвольный код
}

const userInput1: string = "sensitiveFile.txt";

function readFile(fileName: string): void {
  fs.readFile(
    fileName,
    "utf8",
    (err: NodeJS.ErrnoException | null, data: string) => {
      // Использование переменной в функции fs. Возможность атаки с обходом пути для получения доступа к файлам
      if (err) {
        console.error("Ошибка чтения файла:", err);
      } else {
        console.log("Содержимое файла:", data);
      }
    }
  );
}

loadModule("express");
readFile(userInput1);

// 2) Взаимодействие с SQL СУБД
import * as mysql from "mysql";

const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "password",
  database: "test",
});

const userId: string = "1";
connection.query(
  `SELECT * FROM users WHERE id = ${userId}`,
  (error: mysql.MysqlError | null, results: any) => {
    // SQL-инъекция через пользовательский ввод
    if (error) throw error;
    console.log(results);
  }
);

// 3) Веб-взаимодействие по HTTP, CORS, cookies

express.csrf();express.methodOverride() // Это может позволить запросам GET (которые не проверяются csrf) позже превращаться в запросы POST

// 4) Работа с памятью

function readData(filePath: string): void {
  const data: Buffer = fs.readFileSync(filePath);
  const buffer: Buffer = new Buffer(data); // использование устаревшего метода new Buffer
  console.log("Данные:", buffer.toString());
}

function writeData(buffer: Buffer, value: number, offset: number): void {
  buffer.writeInt32LE(value, offset, true); // использование флага noAssert позволяет выйти за пределы buffer
  console.log("Записаны данные:", buffer);
}

// 5) Циклы, переключатели, условия

import * as express from "express";
const app = express();

let globalCounter: number = 0;
function updateCounter(data: number[]): number {
  for (let i = 0; i < data.length; i++) {
    if (data[i] % 2 === 0) {
      // Object Injection
      globalCounter++;
    }
  }
  return globalCounter;
}

function isUserValid(user: { isActive: boolean }): boolean {
  if ((user.isActive = false)) {
    // Присваивание вместо проверки
    return false;
  }
  return true;
}

app.listen(3000, () => {
  console.log("Сервер запущен на порту 3000");
});

// 6) Возврат функций

function getUser(id: number): { name: string } | null {
  if (id === 1) {
    return { name: "John" };
  } else {
    return null; // Возвращаемое значение не соответствует ожидаемому
  }
}

// 7) Места инъекций, экранирование

const userInput: string = "name";

connection.query(
  `SELECT * FROM users WHERE name = '${userInput}'`,
  (error: mysql.MysqlError | null, results: any) => {
    // Неэкранированный пользовательский ввод в SQL-запросе
    if (error) throw error;
    console.log(results);
  }
);

const regex: RegExp = /(a+)+$/; // Ошибка: небезопасное регулярное выражение, возможна DOS атака

// 8) Хранение секретных данных
process.env.API_KEY = "my-secret-key_sapegionjaspdginka04987t3048t[oaigvaidsg"; // Использование секретов

// 9) Парсинг XML, JSON

// 11) Стиль программирования

let unusedVar: number = 42; // Неиспользуемая переменная

function greet(name: string, unusedArg: any): void {
  // Неиспользуемый аргумент в функции
  console.log("Hello, " + name);
}

const numbers: number[] = [1, 2, 3, 4, 5];
const doubledNumbers: number[] = [];
for (let i = 0; i < numbers.length; i++) {
  // Можно использовать for-of
  doubledNumbers.push(numbers[i] * 2);
}

const arr = [1, 2, 3]
for (let i = 0; i < arr.length; i++) {
  console.log(arr[i]);
}

try {
  throw new Error("Something went wrong");
} catch (e) { // Неправильное использование try...catch (отсутствие обработки ошибок)
  // Ничего не делаем
}